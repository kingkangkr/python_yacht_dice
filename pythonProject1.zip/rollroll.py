from random import randint

def rollroll():
    dicelist = []
    for i in range(0,5):
        dicelist.append(randint(1,6))
    print(dicelist)
    return dicelist