import score_calc
def scordboard(array):
    turn=12
    remain_scores=[1,2,3,4,5,6,7,8,9,10,11,12]#12개를 하고, 한 번 점수를 저장할 때마다 해당하는
    #번호를 지워서 중복 방지
    menu=int(input("Where do you want to put your score?"
        +"1.Ones 2.Twos 3.Threes 4.Fours 5.Fives 6.Sixes\n "
        +"7.Choices 8.small_straight 9. large_straight\n"
        +"10. Four_kinds 11. Full_house 12. Yacht\n"))
    if menu==1:
        remain_scores.remove(1)
        turn -= 1
        return score_calc.ones(array)
    elif menu==2:
        remain_scores.remove(2)
        turn -= 1
        return score_calc.twos(array)
    elif menu==3:
        remain_scores.remove(3)
        turn -= 1
        return score_calc.threes(array)
    elif menu==4:
        remain_scores.remove(4)
        turn -= 1
        return score_calc.fours(array)
    elif menu==5:
        remain_scores.remove(5)
        turn -= 1
        return score_calc.fives(array)
    elif menu==6:
        remain_scores.remove(6)
        turn -= 1
        return score_calc.sixes(array)
    elif menu==7:
        remain_scores.remove(7)
        turn -= 1
        return score_calc.choice(array)
    elif menu==8:
        remain_scores.remove(8)
        turn -= 1
        return score_calc.small_straight(array)
    elif menu==9:
        remain_scores.remove(9)
        turn -= 1
        return score_calc.large_straight(array)
    elif menu==10:
        remain_scores.remove(10)
        turn -= 1
        return score_calc.four_kind(array)
    elif menu==11:
        remain_scores.remove(11)
        turn -= 1
        return score_calc.full_house(array)
    elif menu==12:
        remain_scores.remove(12)
        turn -= 1
        return score_calc.yacht(array)
    else:
        print("Invalid number")
