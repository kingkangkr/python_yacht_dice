import score_calc
import reroll
import scoreboard
import score_sort
from rollroll import rollroll

if __name__ == "__main__":
    score_list = [0,0,0]
    while True:
        print("To start yacht dice enter 1")
        print("To see high score, enter 2")
        print("To exit, enter 3")
        score=0
        player_turn=12
        menu = int(input("Enter a number"))
        if menu == 1:
            print("start yacht game")
            while player_turn>0:
                player = reroll.reroll(rollroll())
                score += scoreboard.scordboard(player)
                player_turn-=1
                print(str(player_turn)+" turns left")
            print("Your score is " + str(score))
            score_list.append(score)
        elif menu == 2:
            best_scores=score_sort.score_sort(score_list)
            best_scores=score_list[0:3]
            print(best_scores)
        else:
            break
